# Меню дуэлей в BMenu (стиль ElytriX)

Своё меню поверх EpicDuels: те же рамки, звуки и анимация сборки, что в
главном меню сервера. Игрок видит кнопки с объяснением, а не английское GUI.

## Что в комплекте

```
plugins/BMenu/menu/elytrix/duel/
├── duel.yml         главное меню дуэлей (54 слота)
├── queue.yml        выбор кита для очереди (54 слота)
├── help.yml         «Как играть», 4 шага
├── stats.yml        профиль и топ
├── rounds.yml       число раундов: 1 / 3 / 5
├── party.yml        групповая дуэль или турнир
├── party_size.yml   размер команд: 2v2 / 3v3 / 4v4
└── kit.yml          выбор кита (те же 9 китов, что в queue.yml)
```

Плюс мост `ElytrixDuelsBridge-1.0.0.jar`: он подменяет окна самого
EpicDuels на эти меню. Без моста `/duel` показывает меню плагина
(перекрашенное, но без анимации BMenu).

`BMenu/config.yml` — добавлены команды открытия:

```
/duels        (/дуэли)
/duelshelp    (/дуэлипомощь)
```

## Установка

1. Скопировать папку `elytrix/duel` в `plugins/BMenu/menu/elytrix/`.
2. В `plugins/BMenu/config.yml` в `open_commands` добавить блок:

```
  duels:
    menu: elytrix:duel
    aliases:
      - duels
      - дуэли
  duel_help_menu:
    menu: elytrix:duel_help
    aliases:
      - duelshelp
      - дуэлипомощь
```

3. Положить `ElytrixDuelsBridge-1.0.0.jar` в `plugins/` (нужны `EpicDuels`
   и `BMenu`).
4. Перезагрузить сервер.
5. Проверить: `/duel` — должно открыться наше меню с анимацией.

## Что делает каждая кнопка

### Главное меню (`elytrix:duel`)

| Слот | Кнопка | Действие |
|---|---|---|
| 11 | Дуэль 1 на 1 | `/duel duels` — выбор игрока |
| 13 | Поиск соперника | наше меню с китами → `/duel queue <кит>` |
| 15 | Наблюдение | `/duel spectate` |
| 22 | Твой профиль | победы, поражения, процент, очки (PlaceholderAPI, обновляется каждые 2 сек) |
| 24 | Группа | открывает `elytrix:duel_party` (командная дуэль / турнир) |
| 29 | Топ игроков | `/duel leaderboard wins` |
| 31 | Как играть | открывает инструкцию |
| 33 | Статистика | `/duel stats` |
| 49 | Закрыть | закрывает меню, `red_dye` |

### Очередь (`elytrix:duel_queue`)

9 китов: `sword`, `nodebuff`, `uhc`, `sumo`, `gapple`, `archer`, `mace`,
`crystal`, `pot`. Клик → `/duel queue <кит>` и меню закрывается.

**Важно:** имена китов должны совпадать с тем, что создано в EpicDuels
(`/duel kit create sword` и т.д.). Если назовёшь иначе — поправь
`[player] duel queue <имя>` у нужной кнопки в `queue.yml`.

Внизу: `53` — выйти из очереди, `45` — назад, `49` — закрыть.

### Группа (`elytrix:duel_party`) и размер (`elytrix:duel_party_size`)

11 — командная дуэль (→ `/duelx party team` → выбор 2v2/3v3/4v4),
15 — турнир (→ `/duelx party tournament`). Мост проверяет, хватает ли
игроков в группе, и только потом открывает выбор кита.

### Статистика (`elytrix:duel_stats`)

Победы, поражения, процент, очки (PlaceholderAPI), топ и кнопка «Сыграть».

### Раунды (`elytrix:duel_rounds`)

1 / 3 / 5 раундов → `/duelx rounds N`, дальше плагин сам показывает выбор карты.

### Инструкция (`elytrix:duel_help`)

Четыре шага: режим → кит → карта и раунды → бой. Плюс блок «Важно»:
наград нет, инвентарь не трогается, выход из боя = поражение.

## Анимация

Как в главном меню: сначала появляются служебные кнопки (закрыть/назад),
потом по спирали собирается фиолетовая рамка, затем чёрные панели и по
очереди кнопки. Звуки — `block.enchantment_table.use` на старте,
`note_block.chime` на рамке (тон растёт), `note_block.pling` на кнопках,
`amethyst_block.chime` на финале.

Если нужно тише — правь второе число у `sound:` (громкость).
Если нужно быстрее — удаляй кадры рамки, а не кнопок.

## Кнопка в главном меню

Чтобы игроки попадали в дуэли из `/menu`, в `BMenu/menu/elytrix/main/menu.yml`
добавь предмет:

```
  duels:
    material: netherite_sword
    name: '&7« &#F8BEFBДуэли &7»'
    lore:
    - '&#F8BEFB&l┃ '
    - '&#F8BEFB&l┃ &fФормат: &#F8BEFB1 на 1 и команды'
    - '&#F8BEFB&l┃ &fКиты: &#F8BEFB9 готовых'
    - '&#F8BEFB&l┃ '
    - '&7● &fНажмите, чтобы открыть'
    on_click:
    - sound: 'block.note_block.pling 0.4 1.2'
    - '[open] elytrix:duel'
```

И добавь его в `animation:` на свободный слот (например `st: duels 25`).
Файл `main/menu.yml` я не менял — по твоему указанию.

## Мост `ElytrixDuelsBridge`

Мост слушает `InventoryOpenEvent`: если EpicDuels собирается открыть своё
окно, окно отменяется и через тик открывается меню BMenu. Соответствие
задаётся в `plugins/ElytrixDuelsBridge/config.yml`:

| Окно EpicDuels | Меню BMenu |
|---|---|
| `MAIN` | `elytrix:duel` |
| `STATS` | `elytrix:duel_stats` |
| `MATCHMAKING` | `elytrix:duel_queue` |
| `KIT_SELECT` | `elytrix:duel_kit` |
| `PARTY_KIT` | `elytrix:duel_kit` |
| `ROUNDS_SELECT` | `elytrix:duel_rounds` |
| `PARTY_MODE` | `elytrix:duel_party` |
| `PARTY_TEAM_SIZE` | `elytrix:duel_party_size` |

Остаются за плагином только окна с «живым» содержимым: список игроков
(`DUELS`), арены (`ARENA_SELECT`), наблюдение (`SPECTATE`) и подтверждение
группы (`PARTY_CONFIRM`). Их список зависит от сервера, статичным меню его
не показать; они перекрашены через `menus.yml` EpicDuels.

Кнопки новых меню вызывают `/duelx`:

```
/duelx rounds <1|3|5>            передать раунды и открыть выбор карты
/duelx kit <кит>                 выбранный кит → раунды или подтверждение
/duelx party <team|tournament>   групповая дуэль или турнир
/duelx size <2|3|4>              размер команд и выбор кита
/duelx open <menu>               открыть меню BMenu по id
```

`/duelx` дергает публичные методы `GUIManager` — то же, что делает клик в
окне плагина, — и проверяет то же, что плагин: включены ли `team-duels` и
`tournaments`, хватает ли игроков в группе. Ошибки не ломают меню: игрок
видит «В группе мало игроков: нужно 4, сейчас 2».

## Ограничения EpicDuels

- `/duel challenge` и `/duel duels` открывают **своё** окно выбора игрока,
  кита и карты — из команды кит не передать. Поэтому цепочка вызова
  проходит через окна плагина, а всё остальное (очередь, профиль, топ,
  инструкция) — наше меню.
- Рамки внутри окон плагина рисует сам плагин, их цвет конфигом не меняется.
- Профиль в главном меню требует PlaceholderAPI и включённого расширения
  EpicDuels (оно ставится само, если PAPI есть на сервере).
