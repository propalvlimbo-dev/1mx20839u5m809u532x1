Полный BMenu — конфиги меню ElytriX
===================================

Что внутри
----------
BMenu/config.yml      — конфиг BMenu
BMenu/reference.yml   — справочник возможностей BMenu (не грузится как меню)
BMenu/menu/           — все меню (56 файлов):
  bauc/               — аукцион BAuctionV2 (11 файлов + README)
  elytrix/            — главное меню, магазин, кейсы, ивенты, хелп, лобби, зарплата
  admin/              — админские меню
  select/             — выбор темы
  random-colors/      — тестовое меню со случайными цветами
  include-example/    — примеры include

Установка
---------
1. Полный stop сервера.
2. Скопировать содержимое BMenu/ в plugins/BMenu/, заменив старые файлы.
   (config.yml, reference.yml и папку menu/)
3. Запустить сервер.
4. В логе не должно быть "unknown provider bauc:" и ошибок разбора YAML.
5. /bmenu reload -> "Reloaded N menus!"; в игре /menu и /ah.

Если /ah пишет "Menu not found: bauc:home"
-------------------------------------------
Полный stop -> start (не /reload и не /plugman reload).
Подробнее — BMenu/menu/bauc/README.md.

Замечание
---------
Папка include-example/ в BMenu 2.7 может ломать загрузку, если препроцессор
встретит многострочный include. Если в логе будут ошибки по этим файлам —
удалите папку include-example из plugins/BMenu/menu/.
