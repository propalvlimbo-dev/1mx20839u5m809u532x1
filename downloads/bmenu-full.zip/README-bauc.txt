Аукцион ElytriX — меню BMenu (bauc)
====================================

Что внутри
----------
bauc/                  — содержимое plugins/BMenu/menu/bauc/ (11 меню + README)
previews/              — кадры анимации (GIF/PNG)
tools/                 — fix-bcases-menu.ps1 (чистка plugins\BCases\menu)
ПРАВА-И-СЛОТЫ.md       — лимиты лотов и LuckPerms

КУДА КЛАСТЬ (важно)
-------------------
Только в plugins/BMenu/menu/  — плагин BMenu 2.7.
НЕ в plugins/BCases/menu/ — ту папку читает BMenu 1.6 из библиотек BCases,
и он падает с "Expected a Map, but found List" на on_click.

Установка
---------
1. Полный stop сервера (не /reload).
2. Скопировать папку bauc в plugins/BMenu/menu/, заменив старую целиком.
3. При необходимости выполнить tools/fix-bcases-menu.ps1 (см. выше).
4. Запустить сервер. В логе не должно быть "unknown provider bauc:".
5. В игре: /ah

Слоты для донатов
-----------------
См. ПРАВА-И-СЛОТЫ.md. Кратко: /lp group vip permission set bauc.vip true
(5 слотов), надбавки — bauc.add1..4. Без прав у игрока 0 слотов,
поэтому bauc.default обязателен для группы default.

Что в этой версии
-----------------
- Валюты: коины — ₡, монеты — ⛂.
- Слот 47: бумага (paper) с памяткой «Как выставлять лоты».
- Рамка /ah и хранилища — железная цепь (iron_chain).
- Анимация "цепная клетка", звуки block.chain.*.
- Аренда слотов: раскладка панелей как в главном меню /menu.
